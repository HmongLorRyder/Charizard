function setup() { 
  createCanvas(400, 400);
  strokeWeight(3);
  
} 

function draw() {
  noFill();
  stroke(0-255);
  background(167);
  
  //house
  rect(100,200,200,200);
  
  //chimney
  rect(120,120,20,60);
  
  //roof
  triangle(100,200, 300,200, 200,100);
  
  //door
  rect(145,350,30,50);
  
  //door knob
  ellipse(150,380,5,5);
  
  //window
  rect(130,270,40,40);
  
  //window
  rect(225,270,40,40);
}