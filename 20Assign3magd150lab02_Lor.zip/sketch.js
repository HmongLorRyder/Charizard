let bubbles =[]; 
function setup() {
  createCanvas(800, 800);
  for (let b = 0; b < 1; b++){
  	bubbles[b] = new Bubble(random(width),random(800,800));
  }
  let numArray = [3, 2, 6, 5, 9, 0];
  fill(0);
  noStroke();
  text('Array Elements', 0, 30);
  let spacing = 35;
  let elemsY = 55;
  for (let i = 0; i < numArray.length; i++) {
    text(numArray[i], i * spacing, elemsY);
  }
  let maxX = 33;
  let maxY = 80;
  textSize(32);
  text(min(numArray), maxX, maxY);
}

function draw() {
  background(0,0,150);
  for (let b = 0; b < bubbles.length; b++){
  bubbles[b].show();
  bubbles[b].move();
  }
}

function mousePressed(){
	append(bubbles, new Bubble(mouseX,mouseY));

   {
  background(200);

  let leftWall = 20;
  let rightWall = 80;

  let xm = mouseX;
  let xc = constrain(mouseX, leftWall, rightWall);

  stroke(100);
  line(leftWall, 0, leftWall, height);
  line(rightWall, 0, rightWall, height);

  noStroke();
  fill(150);
  ellipse(xm, 44, 9, 9);
  fill(0);
  ellipse(xc, 88, 9, 9);
   }
}

class Bubble {
	constructor(tempx,tempy){
  	this.x = tempx;
    this.y = tempy;
    this.size = random(20,50);
    this.r = random(255);
    this.g = random(255);
    this.b = random(255);
  }
  
  move(){
  	this.x += random(-8,8);
  	this.y += random(-9,-3);
    if (this.y < 0){
        this.y = random(height,height+200);
        }
    if (this.x>width){
        this.x = 0;
        }
    if (this.x < 0){
    	this.x = width;
    }
  }
  
  show(){
  	stroke(255);
  	strokeWeight(3);
  	fill(this.r,this.g,this.b,200);
  	ellipse(this.x,this.y,this.size,this.size);
  }
}
