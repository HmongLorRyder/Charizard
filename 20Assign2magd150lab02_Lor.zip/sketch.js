function setup() {
  createCanvas(400, 400);
}

function draw() 
  {background(51);
  
  arc(125, 230, 150, 150, 0, PI + QUARTER_PI, CHORD);
   
  let c = color(255, 204, 0)
  fill(c)
  noStroke()
  circle(170, 170, 200);
  
  let a = color(255, 50, 0)
  fill(a)
  noStroke()
  circle(300, 300, 50);
  
  let q = color(127, 255, 0)
  fill(q)
  noStroke()
  quad(38, 31, 86, 20, 69, 63, 30, 76);

  noFill();
  stroke(255);
  bezier(250, 250, 0, 100, 100, 0, 100, 0, 0, 0, 100, 0);
   
}